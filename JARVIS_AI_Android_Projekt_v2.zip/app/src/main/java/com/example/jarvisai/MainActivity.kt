package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var memory: EditText
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val cyan = Color.rgb(57, 213, 255)
    private val bg = Color.rgb(5, 11, 24)
    private val panel = Color.rgb(12, 25, 45)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale.GERMAN
            tts.setSpeechRate(0.88f)
            tts.setPitch(0.88f)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 28f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        }
        val sub = TextView(this).apply {
            text = "PERSÖNLICHER ASSISTENT  •  VERSION 1.0"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 18)
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 58f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        addMessage("JARVIS", "Guten Tag. Ich bin bereit. Wie kann ich Ihnen helfen?")
        val scroll = ScrollView(this).apply {
            addView(chat)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Nachricht an JARVIS …"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            setPadding(12, 8, 12, 8)
            setBackgroundColor(panel)
        }
        val send = makeButton("SENDEN")
        send.setOnClickListener { sendText(input.text.toString()) }
        row.addView(input, LinearLayout.LayoutParams(0, 54, 1f))
        row.addView(send)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val mic = makeButton("🎙 SPRECHEN")
        mic.setOnClickListener { startListening() }
        val speak = makeButton("🔊 LETZTE ANTWORT")
        speak.setOnClickListener {
            val last = prefs.getString("last_reply", "Ich bin bereit.") ?: "Ich bin bereit."
            say(last)
        }
        controls.addView(mic, LinearLayout.LayoutParams(0, 52, 1f))
        controls.addView(speak, LinearLayout.LayoutParams(0, 52, 1f))
        val memTitle = TextView(this).apply {
            text = "MEIN GEDÄCHTNIS"
            setTextColor(cyan)
            textSize = 12f
            setPadding(0, 18, 0, 6)
        }
        memory = EditText(this).apply {
            hint = "Wichtige Notiz für JARVIS …"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setText(prefs.getString("memory", "") ?: "")
            minLines = 2
            setPadding(12, 8, 12, 8)
            setBackgroundColor(panel)
        }
        val save = makeButton("GEDÄCHTNIS SPEICHERN")
        save.setOnClickListener {
            prefs.edit().putString("memory", memory.text.toString()).apply()
            addMessage("SYSTEM", "Gedächtnis wurde auf diesem Gerät gespeichert.")
        }
        val note = TextView(this).apply {
            text = "Hinweis: Version 1 nutzt Android-Spracherkennung und die installierte deutsche Systemstimme. Das Aktivierungswort im Hintergrund ist noch nicht enthalten."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 0)
        }

        root.addView(title)
        root.addView(sub)
        root.addView(orb)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row)
        root.addView(controls)
        root.addView(memTitle)
        root.addView(memory)
        root.addView(save)
        root.addView(note)
        setContentView(root)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 10f
        setTextColor(cyan)
        setBackgroundColor(Color.rgb(18, 43, 67))
        isAllCaps = false
    }

    private fun addMessage(who: String, text: String) {
        val tv = TextView(this).apply {
            this.text = "$who  ›  $text"
            textSize = 14f
            setTextColor(if (who == "JARVIS") Color.WHITE else cyan)
            setPadding(4, 8, 4, 8)
        }
        chat.addView(tv)
    }

    private fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        addMessage("DU", clean)
        input.setText("")
        val saved = prefs.getString("memory", "") ?: ""
        val reply = when {
            clean.contains("wie heißt", true) -> "Ich bin JARVIS, Ihr persönlicher Assistent."
            clean.contains("merk dir", true) -> {
                val item = clean.substringAfter("merk dir", "").trim()
                if (item.isNotEmpty()) {
                    val updated = (saved + "\n" + item).trim()
                    prefs.edit().putString("memory", updated).apply()
                    memory.setText(updated)
                    "Verstanden. Ich habe es im lokalen Gedächtnis notiert."
                } else "Was genau soll ich mir merken?"
            }
            clean.contains("gedächtnis", true) || clean.contains("erinnerung", true) ->
                if (saved.isBlank()) "Mein Gedächtnis ist noch leer." else "In meinem lokalen Gedächtnis steht: $saved"
            clean.contains("uhrzeit", true) -> "Die aktuelle Gerätezeit ist " + java.text.SimpleDateFormat("HH:mm", Locale.GERMANY).format(java.util.Date()) + " Uhr."
            clean.contains("einstellungen", true) -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                "Ich öffne die Einstellungen."
            }
            else -> "Ich habe Ihre Nachricht verstanden. Diese erste Version arbeitet noch ohne angeschlossenes Sprachmodell. Die lokale Notizfunktion und Sprachausgabe sind bereit."
        }
        addMessage("JARVIS", reply)
        prefs.edit().putString("last_reply", reply).apply()
        say(reply)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprechen Sie mit JARVIS")
            }
            startActivityForResult(intent, 43)
        } catch (_: Exception) {
            addMessage("SYSTEM", "Auf diesem Gerät ist kein Spracherkennungsdienst verfügbar.")
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 43 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) sendText(spoken)
        }
    }

    private fun say(text: String) {
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
